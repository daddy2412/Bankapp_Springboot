package com.example.bankapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankappApplicationTests {

	@Test
	void contextLoads() {
	}

}
